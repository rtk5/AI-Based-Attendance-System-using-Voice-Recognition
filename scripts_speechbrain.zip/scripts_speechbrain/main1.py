import os
import sys
import logging
import pickle
from scripts.convert_to_wav1 import convert_to_wav
from scripts.check_sampling_rate import check_sampling_rate
from scripts.preprocess_audio1 import preprocess_audio
from scripts.speaker_recognition1 import ImprovedSpeakerRecognizer

def setup_logging():
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s: %(message)s',
        handlers=[
            logging.StreamHandler(sys.stdout),
            logging.FileHandler('attendance_system.log')
        ]
    )

def create_or_load_database(recognizer, db_path, folder_paths):
    if os.path.exists(db_path):
        logging.info("Loading existing speaker database.")
        with open(db_path, 'rb') as f:
            return pickle.load(f)
    else:
        logging.info("Creating a new speaker database.")
        speaker_database = recognizer.create_speaker_database(folder_paths)
        with open(db_path, 'wb') as f:
            pickle.dump(speaker_database, f)
        return speaker_database

def run_pipeline():
    setup_logging()
    logger = logging.getLogger(__name__)

    try:
        base_dir = 'C:\\COLLEGE\\attendance system'
        input_folder_sir = os.path.join(base_dir, 'all_voice_recordings', 'present_sir')
        input_folder_maam = os.path.join(base_dir, 'all_voice_recordings', 'present_maam')
        output_folder_sir = os.path.join(base_dir, 'preprocessed_audio', 'present_sir')
        output_folder_maam = os.path.join(base_dir, 'preprocessed_audio', 'present_maam')
        models_dir = os.path.join(base_dir, 'models')
        db_path = os.path.join(base_dir, 'speaker_database.pkl')

        os.makedirs(models_dir, exist_ok=True)
        os.makedirs(output_folder_sir, exist_ok=True)
        os.makedirs(output_folder_maam, exist_ok=True)

        logger.info("Step 1: Converting audio to WAV...")
        convert_to_wav(input_folder_sir, output_folder_sir)
        convert_to_wav(input_folder_maam, output_folder_maam)

        logger.info("Step 2: Checking sampling rates...")
        check_sampling_rate(output_folder_sir)
        check_sampling_rate(output_folder_maam)

        logger.info("Step 3: Preprocessing audio...")
        preprocess_audio(output_folder_sir, output_folder_sir)
        preprocess_audio(output_folder_maam, output_folder_maam)

        recognizer = ImprovedSpeakerRecognizer()
        speaker_database = create_or_load_database(recognizer, db_path, [output_folder_sir, output_folder_maam])

        while True:
            test_file_path = input("\nEnter path to the test audio file (or 'q' to quit): ").strip('"')
            
            if test_file_path.lower() == 'q':
                break

            if not os.path.isfile(test_file_path):
                logger.error(f"Error: File not found - {test_file_path}")
                continue

            # Test with COSINE Distance Metric
            logger.info("--- Testing with COSINE Distance Metric ---")
            recognized_speaker = recognizer.identify_speaker(test_file_path, speaker_database)

            if recognized_speaker and recognized_speaker != "Unknown":
                logger.info(f"Recognized Speaker (cosine): {recognized_speaker}")
            else:
                logger.info("No confident speaker match found.")
    
    except Exception as e:
        logger.error(f"An error occurred in the pipeline: {e}", exc_info=True)

if __name__ == "__main__":
    run_pipeline()
