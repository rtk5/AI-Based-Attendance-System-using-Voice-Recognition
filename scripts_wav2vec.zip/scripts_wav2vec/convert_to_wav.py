import os
import subprocess
#subprocess is used to call FFmpeg (a powerful multimedia framework) to convert audio files to .wav.

def convert_to_wav(input_folder, output_folder):
    # Use absolute paths
    input_folder = os.path.abspath("C:\\COLLEGE\\attendance system\\all_voice_recordings")
    output_folder = os.path.abspath("C:\\COLLEGE\\attendance system\\preprocessed_audio")

    # Ensure output folder exists
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    # Process both subdirectories: present-sir and present-maam
    for subfolder in ["present_sir", "present_maam"]:
        input_path = os.path.join(input_folder, subfolder)
        output_path = os.path.join(output_folder, subfolder)

        if not os.path.exists(output_path):
            os.makedirs(output_path)

        for file_name in os.listdir(input_path):
            # Check for supported formats
            if file_name.lower().endswith(('.ogg', '.m4a', '.mp3')):
                input_file = os.path.join(input_path, file_name)
                output_file = os.path.join(output_path, os.path.splitext(file_name)[0] + ".wav")
                
                print(f"Converting: {input_file} -> {output_file}")
                
                try:
                    #subprocess.run(["ffmpeg", "-i", input_file, output_file], check=True)
                    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", input_file, output_file], check=True)
                    print(f"Successfully converted {file_name} to WAV.")
                except subprocess.CalledProcessError as e:
                    print(f"Error converting {file_name}: {e}")

if __name__ == "__main__":
    convert_to_wav()
