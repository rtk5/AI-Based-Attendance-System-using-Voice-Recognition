import os
import torch
import librosa
import numpy as np
from transformers import Wav2Vec2Processor, Wav2Vec2ForSequenceClassification
from sklearn.metrics.pairwise import cosine_similarity
import pickle

# Load the processor and model
processor = Wav2Vec2Processor.from_pretrained("facebook/wav2vec2-large-960h")
model = Wav2Vec2ForSequenceClassification.from_pretrained("facebook/wav2vec2-large-960h")
model.eval()

def extract_features(audio_path):
    # Load the audio and ensure it's at 16kHz
    audio_data, sr = librosa.load(audio_path, sr=16000)
    input_values = processor(audio_data, return_tensors="pt", sampling_rate=16000).input_values
    
    with torch.no_grad():
        embeddings = model(input_values).logits
    
    return embeddings.numpy()

def create_database(folder_path_sir, folder_path_maam, model_path, db_path):
    speaker_vectors = {}
    
    # Process 'present_sir'
    for filename in os.listdir(folder_path_sir):
        if filename.endswith(".wav"):
            file_path = os.path.join(folder_path_sir, filename)
            embeddings = extract_features(file_path)
            speaker_name = os.path.splitext(filename)[0]
            speaker_vectors[speaker_name] = embeddings
            print(f"Saved embedding for {speaker_name}")

    # Process 'present_maam'
    for filename in os.listdir(folder_path_maam):
        if filename.endswith(".wav"):
            file_path = os.path.join(folder_path_maam, filename)
            embeddings = extract_features(file_path)
            speaker_name = os.path.splitext(filename)[0]
            speaker_vectors[speaker_name] = embeddings
            print(f"Saved embedding for {speaker_name}")
    
    # Save to database
    with open(db_path, 'wb') as db_file:
        pickle.dump(speaker_vectors, db_file)
    print("Speaker database created and saved.")

def normalize_embedding(embedding):
    return embedding / np.linalg.norm(embedding, axis=1, keepdims=True)

def identify_speaker(audio_path, db_path):
    if not os.path.isfile(audio_path):
        print(f"Error: Test audio file not found at {audio_path}")
        return None

    # Load speaker database
    with open(db_path, 'rb') as db_file:
        speaker_vectors = pickle.load(db_file)

    print(f"Extracting features for: {audio_path}")
    test_embedding = extract_features(audio_path)
    test_embedding = normalize_embedding(test_embedding)
    print(f"Test Embedding Shape: {test_embedding.shape}")

    best_match = None
    best_score = -1
    threshold = 0.8  # Adjustable based on accuracy

    for speaker, embedding in speaker_vectors.items():
        embedding = normalize_embedding(embedding)
        score = cosine_similarity(test_embedding, embedding)[0][0]
        print(f"Comparing with {speaker}, Similarity Score: {score}")
        if score > best_score and score > threshold:
            best_score = score
            best_match = speaker

    if best_match is None:
        print("No speaker identified with confidence.")
        return "Unknown"

    print(f"Recognized Speaker: {best_match} with Similarity Score: {best_score}")
    return best_match
