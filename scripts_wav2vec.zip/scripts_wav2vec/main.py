import os
from scripts.convert_to_wav import convert_to_wav
from scripts.check_sampling_rate import check_sampling_rate
from scripts.preprocess_audio import preprocess_audio
from scripts.speaker_recognition import create_database, identify_speaker

def run_pipeline():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    input_folder_sir = os.path.join(base_dir, 'all_voice_recordings', 'present_sir')
    input_folder_maam = os.path.join(base_dir, 'all_voice_recordings', 'present_maam')
    output_folder_sir = os.path.join(base_dir, 'preprocessed_audio', 'present_sir')
    output_folder_maam = os.path.join(base_dir, 'preprocessed_audio', 'present_maam')
    model_path = os.path.join(base_dir, 'models', 'wav2vec2_model')
    db_path = os.path.join(base_dir, 'models', 'speaker_database.pkl')

    # Step 1: Convert audio to WAV
    print("Step 1: Converting audio to WAV...")
    convert_to_wav(input_folder_sir, output_folder_sir)
    convert_to_wav(input_folder_maam, output_folder_maam)

    # Step 2: Check sampling rates
    print("Step 2: Checking sampling rates...")
    check_sampling_rate(output_folder_sir)
    check_sampling_rate(output_folder_maam)

    # Step 3: Preprocess audio
    print("Step 3: Preprocessing audio...")
    preprocess_audio(output_folder_sir, output_folder_sir)
    preprocess_audio(output_folder_maam, output_folder_maam)

    # Step 4: Clear old database if exists
    if os.path.exists(db_path):
        print("Deleting old database...")
        os.remove(db_path)
    else:
        print("No previous database found.")

    # Step 5: Create Speaker Database
    print("Step 4: Creating Speaker Database...")
    create_database(output_folder_sir, output_folder_maam, model_path, db_path)

    # Step 6: Identify Speaker
    print("Step 5: Identifying Speakers...")
    test_file_path = input("Enter path to the test audio file: ").strip('"')
    if not os.path.isfile(test_file_path):
        print(f"Error: File not found - {test_file_path}")
        return

    recognized_speaker = identify_speaker(test_file_path, db_path)
    print(f"Recognized Speaker: {recognized_speaker if recognized_speaker else 'Unknown'}")

    print("Pipeline Completed!")

if __name__ == "__main__":
    run_pipeline()
